package com.example.springsecurityapplication.repositories;

import com.example.springsecurityapplication.models.Order;
import com.example.springsecurityapplication.models.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {
    List<Order> findByPerson(Person person);

//    Object findByName4(String toLowerCase, int i);
//
//    Object findByName4IgnoreCase(String search);
//
//    Optional<Order> findOrderFindByNumber4(String number);
}


